package writing_Files;

import java.io.FileWriter;

public class writing_files {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] lineas = {"One", "Two", "Three", "four", "five", "..."};
		FileWriter file = null;
		try{
			file = new FileWriter("file_write.txt");// We write each element in a line of the file
			for(int i=0; i<lineas.length; i++) {
				file.write(lineas[i] + "\n");
			}
				file.close();
				System.out.println("¡Writing completed!");
				} catch(Exception ex) {
				System.out.println("ERROR: \n"+ ex.getMessage());
				}

	}

}
