package file_read;

import java.io.File;
import java.util.Scanner;

public class file_read {

	public static void main(String[] args) {
		
		File fichero = new File("fichero_leer.txt"); // Read the file
		Scanner sc = null;
		System.out.println("... The file is read ...");
		try {
			sc = new Scanner(fichero); // Configure to read from file
			while(sc.hasNextLine()) { // Read line by line
				String line= sc.nextLine(); // Save to String
				System.out.println(line); // We print line
			}
		} 
		
		catch(Exception ex) { 
			System.out.println("ERROR: \n"+ ex.getMessage()); 
		}
		finally { // File is closed
			try {
					if(sc != null) { sc.close(); }
				} catch(Exception ex2) { System.out.println("ERROR2: \n"+ ex2.getMessage()); }
		}

	}

}


